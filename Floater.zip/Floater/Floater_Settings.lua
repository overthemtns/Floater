-------------------------------------------------------------------------------
-- Floater_Settings.lua  v5.0
-- Settings panel with HSV color wheel picker
-- Tab 1: Global  |  Tab 2: Groups  |  Tab 3: Text Types
-------------------------------------------------------------------------------

local S = {}
S.frame       = nil
S.activeTab   = 1
S.activeGroup = 1
S.typeRows    = {}
S.panels      = {}
S.tabs        = {}

local FONT = "Fonts\\FRIZQT__.TTF"

-------------------------------------------------------------------------------
-- COLOR MATH  (HSV <-> RGB, all values 0-1)
-------------------------------------------------------------------------------
local function hsvToRgb(h, s, v)
    if s == 0 then return v, v, v end
    h = h * 6
    local i = math.floor(h)
    local f = h - i
    local p = v * (1 - s)
    local q = v * (1 - s * f)
    local t = v * (1 - s * (1 - f))
    local r, g, b
    if     i == 0 then r,g,b = v,t,p
    elseif i == 1 then r,g,b = q,v,p
    elseif i == 2 then r,g,b = p,v,t
    elseif i == 3 then r,g,b = p,q,v
    elseif i == 4 then r,g,b = t,p,v
    else               r,g,b = v,p,q
    end
    return r, g, b
end

local function rgbToHsv(r, g, b)
    local maxC = math.max(r, g, b)
    local minC = math.min(r, g, b)
    local v = maxC
    local d = maxC - minC
    local s = (maxC == 0) and 0 or (d / maxC)
    local h = 0
    if d ~= 0 then
        if     maxC == r then h = (g - b) / d; if g < b then h = h + 6 end
        elseif maxC == g then h = (b - r) / d + 2
        else                   h = (r - g) / d + 4
        end
        h = h / 6
    end
    return h, s, v
end

local function toHex(r, g, b)
    return string.format("%02x%02x%02x",
        math.floor((r or 0)*255+.5),
        math.floor((g or 0)*255+.5),
        math.floor((b or 0)*255+.5))
end
local function fromHex(h)
    h = h or "ffffff"
    if string.len(h) ~= 6 then return 1, 1, 1 end
    return (tonumber(string.sub(h,1,2),16) or 255)/255,
           (tonumber(string.sub(h,3,4),16) or 255)/255,
           (tonumber(string.sub(h,5,6),16) or 255)/255
end

-------------------------------------------------------------------------------
-- SHARED WIDGET HELPERS
-------------------------------------------------------------------------------
local function applyBackdrop(f)
    f:SetBackdrop({
        bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",
        tile=true, tileSize=16, edgeSize=16,
        insets={left=5,right=5,top=5,bottom=5},
    })
    f:SetBackdropColor(0.05, 0.05, 0.08, 0.98)
    f:SetBackdropBorderColor(0.40, 0.35, 0.25, 1)
end

local function applyInset(f)
    f:SetBackdrop({
        bgFile="Interface\\ChatFrame\\ChatFrameBackground",
        edgeFile="Interface\\ChatFrame\\ChatFrameBackground",
        tile=true, tileSize=4, edgeSize=1,
        insets={left=1,right=1,top=1,bottom=1},
    })
    f:SetBackdropColor(0.04, 0.04, 0.07, 1)
    f:SetBackdropBorderColor(0.30, 0.28, 0.20, 1)
end

local function mkLbl(parent, text, x, y, size, r, g, b)
    local fs = parent:CreateFontString(nil, "OVERLAY")
    fs:SetFont(FONT, size or 11, "OUTLINE")
    fs:SetTextColor(r or 0.90, g or 0.85, b or 0.70, 1)
    fs:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    fs:SetText(text)
    return fs
end

local function mkSep(parent, x, y, w)
    local f = CreateFrame("Frame", nil, parent)
    f:SetWidth(w or 400); f:SetHeight(1)
    f:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    local t = f:CreateTexture(nil, "BACKGROUND")
    t:SetAllPoints(f); t:SetTexture(0.30, 0.26, 0.18, 0.8)
end

local function mkBtn(parent, text, w, h, x, y)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetWidth(w); b:SetHeight(h)
    b:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    b:SetText(text)
    return b
end

local function mkEB(parent, w, h, x, y, maxch)
    local eb = CreateFrame("EditBox", nil, parent)
    eb:SetWidth(w); eb:SetHeight(h)
    eb:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    eb:SetFont(FONT, 11, ""); eb:SetTextColor(1, 1, 1, 1)
    eb:SetMaxLetters(maxch or 32); eb:SetAutoFocus(false)
    applyInset(eb)
    eb:SetScript("OnEscapePressed", function() this:ClearFocus() end)
    return eb
end

local slCnt = 0
local function mkSlider(parent, minV, maxV, step, x, y, w, lo, hi)
    slCnt = slCnt + 1
    local sl = CreateFrame("Slider", "FloaterSL"..slCnt, parent, "OptionsSliderTemplate")
    sl:SetWidth(w); sl:SetHeight(16)
    sl:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    sl:SetMinMaxValues(minV, maxV); sl:SetValueStep(step)
    getglobal(sl:GetName().."Low"):SetText(lo or tostring(minV))
    getglobal(sl:GetName().."High"):SetText(hi or tostring(maxV))
    getglobal(sl:GetName().."Text"):SetText("")
    local vl = parent:CreateFontString(nil, "OVERLAY")
    vl:SetFont(FONT, 11, "OUTLINE"); vl:SetTextColor(1, 0.88, 0.35, 1)
    vl:SetPoint("LEFT", sl, "RIGHT", 6, 0); vl:SetText(tostring(minV))
    sl._vl = vl
    return sl, vl
end

-------------------------------------------------------------------------------
-- COLOR WHEEL POPUP
-- A floating popup with:
--   • 128x128 hue/saturation disc (drawn with gradient textures layered)
--   • Brightness bar on the right
--   • Live preview swatch + hex readout
-- Opens when the user clicks a color swatch in the Types list.
-- Calls a callback(r,g,b) when closed or when color changes.
-------------------------------------------------------------------------------
local CW = {}        -- color wheel state
CW.popup    = nil
CW.callback = nil    -- function(r,g,b) called on change
CW.h        = 0      -- current hue        0-1
CW.s        = 0      -- current saturation  0-1
CW.v        = 1      -- current brightness  0-1
CW.dragging = false  -- dragging wheel?
CW.draggingBar = false

local WHEEL_SIZE = 128
local BAR_W      = 18
local BAR_H      = 128
local POPUP_W    = WHEEL_SIZE + BAR_W + 28   -- 174
local POPUP_H    = WHEEL_SIZE + 52

-- Draw the wheel using a grid of colored textures (8x8 cells — good enough)
local WHEEL_SEGS = 32   -- segments around hue ring
local WHEEL_RINGS = 2   -- inner (low sat) and outer (full sat) — we use gradient trick

local function buildColorWheel()
    if CW.popup then return end

    local f = CreateFrame("Frame", "FloaterColorWheel", UIParent)
    f:SetWidth(POPUP_W); f:SetHeight(POPUP_H)
    f:SetFrameStrata("FULLSCREEN_DIALOG")
    f:SetMovable(true); f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", function() this:StartMoving() end)
    f:SetScript("OnDragStop",  function() this:StopMovingOrSizing() end)
    applyBackdrop(f)

    -- Title bar
    local title = f:CreateFontString(nil, "OVERLAY")
    title:SetFont(FONT, 11, "OUTLINE"); title:SetTextColor(1, 0.78, 0.22, 1)
    title:SetPoint("TOP", f, "TOP", 0, -7); title:SetText("Pick Color")

    -- Close button
    local closeBtn = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    closeBtn:SetWidth(18); closeBtn:SetHeight(18)
    closeBtn:SetPoint("TOPRIGHT", f, "TOPRIGHT", 1, 1)
    closeBtn:SetScript("OnClick", function() CW.popup:Hide() end)

    -- ── Hue/Saturation wheel area ────────────────────────────────────────────
    -- We can't draw a real circular gradient in 1.12 without custom textures,
    -- so we build a SQUARE HSV picker instead:
    --   X axis = Hue (0 left → 1 right)
    --   Y axis = Saturation (0 bottom → 1 top)
    -- Brightness is controlled by the separate slider bar.
    -- We tile it with a grid of colored quads for visual fidelity.

    local GRID = 16   -- 16x16 grid of color quads
    local CELL = WHEEL_SIZE / GRID
    local wheelFrame = CreateFrame("Frame", nil, f)
    wheelFrame:SetWidth(WHEEL_SIZE); wheelFrame:SetHeight(WHEEL_SIZE)
    wheelFrame:SetPoint("TOPLEFT", f, "TOPLEFT", 10, -22)
    wheelFrame:EnableMouse(true)

    -- Draw grid cells
    local cells = {}
    for row = 0, GRID-1 do
        cells[row] = {}
        for col = 0, GRID-1 do
            local cell = wheelFrame:CreateTexture(nil, "BACKGROUND")
            cell:SetWidth(CELL+1); cell:SetHeight(CELL+1)
            cell:SetPoint("TOPLEFT", wheelFrame, "TOPLEFT", col*CELL, -row*CELL)
            cells[row][col] = cell
        end
    end
    CW.cells = cells
    CW.wheelFrame = wheelFrame
    CW.GRID = GRID
    CW.CELL = CELL

    -- Cursor crosshair on the wheel
    local cursor = CreateFrame("Frame", nil, wheelFrame)
    cursor:SetWidth(8); cursor:SetHeight(8)
    cursor:SetFrameStrata("FULLSCREEN_DIALOG")
    local cH = cursor:CreateTexture(nil, "OVERLAY")
    cH:SetTexture(1,1,1,1); cH:SetWidth(8); cH:SetHeight(2)
    cH:SetPoint("CENTER", cursor, "CENTER", 0, 0)
    local cV = cursor:CreateTexture(nil, "OVERLAY")
    cV:SetTexture(1,1,1,1); cV:SetWidth(2); cV:SetHeight(8)
    cV:SetPoint("CENTER", cursor, "CENTER", 0, 0)
    -- black outline
    local cHB = cursor:CreateTexture(nil, "BACKGROUND")
    cHB:SetTexture(0,0,0,0.8); cHB:SetWidth(10); cHB:SetHeight(4)
    cHB:SetPoint("CENTER", cursor, "CENTER", 0, 0)
    CW.cursor = cursor

    -- Wheel mouse interaction
    wheelFrame:SetScript("OnMouseDown", function()
        CW.dragging = true
        CW:updateFromWheel()
    end)
    wheelFrame:SetScript("OnMouseUp",   function() CW.dragging = false end)

    -- ── Brightness bar ───────────────────────────────────────────────────────
    local barFrame = CreateFrame("Frame", nil, f)
    barFrame:SetWidth(BAR_W); barFrame:SetHeight(BAR_H)
    barFrame:SetPoint("TOPLEFT", f, "TOPLEFT", WHEEL_SIZE + 16, -22)
    barFrame:EnableMouse(true)

    -- Draw brightness bar as 16 horizontal strips
    local BAR_SEGS = 16
    local barCells = {}
    for i = 0, BAR_SEGS-1 do
        local bc = barFrame:CreateTexture(nil, "BACKGROUND")
        bc:SetWidth(BAR_W); bc:SetHeight(BAR_H / BAR_SEGS + 1)
        bc:SetPoint("TOPLEFT", barFrame, "TOPLEFT", 0, -(i * BAR_H / BAR_SEGS))
        barCells[i] = bc
    end
    CW.barCells = barCells
    CW.barFrame = barFrame
    CW.BAR_SEGS = BAR_SEGS

    -- Bar cursor (horizontal line)
    local barCursor = barFrame:CreateTexture(nil, "OVERLAY")
    barCursor:SetWidth(BAR_W + 4); barCursor:SetHeight(2)
    barCursor:SetTexture(1, 1, 1, 1)
    barCursor:SetPoint("LEFT", barFrame, "LEFT", -2, 0)
    CW.barCursor = barCursor

    barFrame:SetScript("OnMouseDown", function() CW.draggingBar = true;  CW:updateFromBar() end)
    barFrame:SetScript("OnMouseUp",   function() CW.draggingBar = false end)

    -- ── Preview swatch ───────────────────────────────────────────────────────
    local swFrame = CreateFrame("Frame", nil, f)
    swFrame:SetWidth(40); swFrame:SetHeight(24)
    swFrame:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 10, 10)
    applyInset(swFrame)
    local swTex = swFrame:CreateTexture(nil, "ARTWORK")
    swTex:SetAllPoints(swFrame); swTex:SetTexture(1, 1, 1, 1)
    CW.swTex = swTex

    -- Hex display
    local hexLbl = f:CreateFontString(nil, "OVERLAY")
    hexLbl:SetFont(FONT, 10, "OUTLINE"); hexLbl:SetTextColor(0.85, 0.85, 0.85, 1)
    hexLbl:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 58, 14)
    hexLbl:SetText("#ffffff")
    CW.hexLbl = hexLbl

    -- OK button
    local okBtn = mkBtn(f, "OK", 50, 22, POPUP_W - 62, -(POPUP_H - 10))
    okBtn:SetScript("OnClick", function() CW.popup:Hide() end)

    -- OnUpdate: handle drag
    f:SetScript("OnUpdate", function()
        if CW.dragging    then CW:updateFromWheel() end
        if CW.draggingBar then CW:updateFromBar()   end
    end)

    f:Hide()
    CW.popup = f
end

function CW:redrawWheel()
    -- Redraw the hue/sat grid at current brightness
    for row = 0, self.GRID-1 do
        for col = 0, self.GRID-1 do
            local h = col / self.GRID
            local s = 1 - (row / self.GRID)
            local r, g, b = hsvToRgb(h, s, self.v)
            self.cells[row][col]:SetTexture(r, g, b, 1)
        end
    end
end

function CW:redrawBar()
    -- Redraw brightness bar at current hue/sat
    for i = 0, self.BAR_SEGS-1 do
        local bright = 1 - (i / self.BAR_SEGS)
        local r, g, b = hsvToRgb(self.h, self.s, bright)
        self.barCells[i]:SetTexture(r, g, b, 1)
    end
end

function CW:updateCursors()
    -- Wheel cursor: hue=X, sat=Y (sat=1 at top)
    local wx = self.h * WHEEL_SIZE
    local wy = -(1 - self.s) * WHEEL_SIZE
    self.cursor:ClearAllPoints()
    self.cursor:SetPoint("CENTER", self.wheelFrame, "TOPLEFT", wx, wy)

    -- Bar cursor: brightness=Y (bright=1 at top)
    local by = -(1 - self.v) * BAR_H
    self.barCursor:ClearAllPoints()
    self.barCursor:SetPoint("LEFT", self.barFrame, "TOPLEFT", -2, by)
end

function CW:updatePreview()
    local r, g, b = hsvToRgb(self.h, self.s, self.v)
    self.swTex:SetTexture(r, g, b, 1)
    self.hexLbl:SetText("#"..toHex(r, g, b))
    if self.callback then self.callback(r, g, b) end
end

function CW:fullRedraw()
    self:redrawWheel()
    self:redrawBar()
    self:updateCursors()
    self:updatePreview()
end

function CW:updateFromWheel()
    local mx, my = GetCursorPosition()
    local scale  = self.wheelFrame:GetEffectiveScale()
    local fl, fb = self.wheelFrame:GetLeft(), self.wheelFrame:GetBottom()
    if not fl then return end
    local lx = mx / scale - fl
    local ly = my / scale - fb
    -- hue = X/W, sat = Y/H (clamped)
    self.h = math.max(0, math.min(1, lx / WHEEL_SIZE))
    self.s = math.max(0, math.min(1, ly / WHEEL_SIZE))
    self:redrawBar()
    self:updateCursors()
    self:updatePreview()
end

function CW:updateFromBar()
    local mx, my = GetCursorPosition()
    local scale  = self.barFrame:GetEffectiveScale()
    local fb     = self.barFrame:GetBottom()
    if not fb then return end
    local ly = my / scale - fb
    self.v = math.max(0, math.min(1, ly / BAR_H))
    self:redrawWheel()
    self:updateCursors()
    self:updatePreview()
end

function CW:open(r, g, b, callback, anchorFrame)
    buildColorWheel()
    self.callback = callback
    self.h, self.s, self.v = rgbToHsv(r or 1, g or 1, b or 1)

    -- Position near the swatch that was clicked
    self.popup:ClearAllPoints()
    if anchorFrame then
        self.popup:SetPoint("TOPLEFT", anchorFrame, "BOTTOMLEFT", -4, -4)
    else
        self.popup:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    end
    self:fullRedraw()
    self.popup:Show()
    self.popup:Raise()
end

-------------------------------------------------------------------------------
-- TAB 1 — GLOBAL
-------------------------------------------------------------------------------
local function buildGlobalTab(parent)
    local p = CreateFrame("Frame", nil, parent)
    p:SetAllPoints(parent); p:Hide()

    mkLbl(p, "GLOBAL FONT SIZE", 14, -10, 11, 1, 0.82, 0.28)
    mkLbl(p, "Per-type sizes override this when set above 0", 14, -23, 9, 0.55, 0.55, 0.55)
    local slFS, vlFS = mkSlider(p, 8, 48, 1, 14, -38, 300)
    slFS:SetScript("OnValueChanged", function()
        local v = math.floor(this:GetValue()); vlFS:SetText(tostring(v))
        local db = Floater_GetDB(); if db then db.fontSize = v end
    end)

    mkSep(p, 10, -60, 400)
    mkLbl(p, "FLOAT DURATION  (seconds)", 14, -70, 11, 1, 0.82, 0.28)
    local slDur, vlDur = mkSlider(p, 5, 50, 1, 14, -86, 300, "0.5", "5.0")
    slDur:SetScript("OnValueChanged", function()
        local v = this:GetValue() / 10
        vlDur:SetText(string.format("%.1f", v))
        local db = Floater_GetDB(); if db then db.duration = v end
    end)

    mkSep(p, 10, -110, 400)
    mkLbl(p, "FLOAT DISTANCE  (pixels)", 14, -120, 11, 1, 0.82, 0.28)
    local slDist, vlDist = mkSlider(p, 10, 200, 5, 14, -136, 300)
    slDist:SetScript("OnValueChanged", function()
        local v = math.floor(this:GetValue()); vlDist:SetText(tostring(v))
        local db = Floater_GetDB(); if db then db.floatDist = v end
    end)

    mkSep(p, 10, -160, 400)
    mkLbl(p, "FLOAT SPEED", 14, -170, 11, 1, 0.82, 0.28)
    mkLbl(p, "How fast text rises  (0.5 = slow, 1.0 = normal, 2.0 = fast)", 14, -183, 9, 0.55, 0.55, 0.55)
    local slSpeed, vlSpeed = mkSlider(p, 2, 30, 1, 14, -198, 260, "0.2", "3.0")
    slSpeed:SetScript("OnValueChanged", function()
        local v = this:GetValue() / 10
        vlSpeed:SetText(string.format("%.1f", v))
        local db = Floater_GetDB(); if db then db.floatSpeed = v end
    end)

    -- Stagger checkbox sits right of the speed slider
    local stagCB = CreateFrame("CheckButton", nil, p, "UICheckButtonTemplate")
    stagCB:SetWidth(22); stagCB:SetHeight(22)
    stagCB:SetPoint("TOPLEFT", p, "TOPLEFT", 290, -194)
    local stagL = p:CreateFontString(nil, "OVERLAY")
    stagL:SetFont(FONT, 11, "OUTLINE"); stagL:SetTextColor(0.9, 0.85, 0.7, 1)
    stagL:SetPoint("LEFT", stagCB, "RIGHT", 2, 0); stagL:SetText("Stagger L/R")
    stagCB:SetScript("OnClick", function()
        local db = Floater_GetDB(); if db then db.stagger = (this:GetChecked() == 1) end
    end)
    p._stagCB = stagCB

    mkSep(p, 10, -222, 400)

    local enCB = CreateFrame("CheckButton", nil, p, "UICheckButtonTemplate")
    enCB:SetWidth(22); enCB:SetHeight(22)
    enCB:SetPoint("TOPLEFT", p, "TOPLEFT", 14, -232)
    local enL = p:CreateFontString(nil, "OVERLAY")
    enL:SetFont(FONT, 11, "OUTLINE"); enL:SetTextColor(0.9, 0.85, 0.7, 1)
    enL:SetPoint("LEFT", enCB, "RIGHT", 2, 0); enL:SetText("Addon Enabled")
    enCB:SetScript("OnClick", function()
        local db = Floater_GetDB(); if not db then return end
        db.enabled = (this:GetChecked() == 1)
        if db.enabled then Floater_Suppress() else Floater_Restore() end
    end)

    mkSep(p, 10, -260, 400)

    -- BOOM toggle
    mkLbl(p, "BOOM", 14, -270, 13, 1, 0.30, 0.05)
    local boomCB = CreateFrame("CheckButton", nil, p, "UICheckButtonTemplate")
    boomCB:SetWidth(22); boomCB:SetHeight(22)
    boomCB:SetPoint("TOPLEFT", p, "TOPLEFT", 14, -284)
    local boomL = p:CreateFontString(nil, "OVERLAY")
    boomL:SetFont(FONT, 11, "OUTLINE"); boomL:SetTextColor(1, 0.40, 0.10, 1)
    boomL:SetPoint("LEFT", boomCB, "RIGHT", 4, 0)
    boomL:SetText("Yell on big crits  (configure in Boom tab)")
    boomCB:SetScript("OnClick", function()
        local db = Floater_GetDB()
        if db and db.boom then
            db.boom.enabled = (this:GetChecked() == 1)
            if S.panels[4] and S.panels[4]._enCB then
                S.panels[4]._enCB:SetChecked(db.boom.enabled and 1 or 0)
            end
        end
    end)
    p._boomCB = boomCB

    mkSep(p, 10, -312, 400)

    local unlockBtn = mkBtn(p, "Unlock Groups", 120, 22, 14, -322)
    unlockBtn:SetScript("OnClick", function()
        if Floater_SetGroupsLocked then Floater_SetGroupsLocked(false) end
    end)
    local lockBtn = mkBtn(p, "Lock Groups", 110, 22, 144, -322)
    lockBtn:SetScript("OnClick", function()
        if Floater_SetGroupsLocked then Floater_SetGroupsLocked(true) end
    end)

    local testBtn = mkBtn(p, "Test All", 80, 22, 262, -322)
    testBtn:SetScript("OnClick", function() Floater_TestSpawn() end)

    local resetBtn = mkBtn(p, "Reset Defaults", 110, 22, 14, -350)
    resetBtn:SetScript("OnClick", function()
        for k, v in pairs(FloaterDefaults) do FloaterDB[k] = v end
        FloaterDB.types = nil; FloaterDB.groups = nil
        S:refreshAll()
    end)

    p._slFS = slFS; p._vlFS = vlFS
    p._slDur = slDur; p._vlDur = vlDur
    p._slDist = slDist; p._vlDist = vlDist
    p._slSpeed = slSpeed; p._vlSpeed = vlSpeed
    p._enCB = enCB
    return p
end

-------------------------------------------------------------------------------
-- TAB 2 — GROUPS
-------------------------------------------------------------------------------
local function buildGroupsTab(parent)
    local p = CreateFrame("Frame", nil, parent)
    p:SetAllPoints(parent); p:Hide()

    local groupTabBtns = {}
    for gi = 1, MAX_GROUPS do
        local tb = CreateFrame("Button", nil, p)
        tb:SetWidth(90); tb:SetHeight(20)
        tb:SetPoint("TOPLEFT", p, "TOPLEFT", 10 + (gi-1)*96, -10)
        local bg = tb:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints(tb); bg:SetTexture(0.10, 0.08, 0.06, 0); tb._bg = bg
        local tl = tb:CreateFontString(nil, "OVERLAY")
        tl:SetFont(FONT, 11, "OUTLINE"); tl:SetAllPoints(tb)
        tl:SetJustifyH("CENTER"); tl:SetTextColor(0.75, 0.70, 0.60, 1)
        tl:SetText("Group "..gi); tb._lbl = tl; tb._gi = gi
        tb:SetScript("OnClick", function()
            S.activeGroup = this._gi; S:refreshGroupsTab()
        end)
        groupTabBtns[gi] = tb
    end
    p._groupTabBtns = groupTabBtns

    mkSep(p, 8, -34, 400)

    mkLbl(p, "Name:", 14, -46, 10)
    local nameEB = mkEB(p, 200, 18, 60, -44, 24)
    nameEB:SetScript("OnEnterPressed", function()
        local db = Floater_GetDB()
        if db and db.groups and db.groups[S.activeGroup] then
            db.groups[S.activeGroup].name = this:GetText()
            if Floater_UpdateGroupPos then Floater_UpdateGroupPos(S.activeGroup) end
            S:refreshGroupTabLabels()
        end
        this:ClearFocus()
    end)
    p._nameEB = nameEB

    local enCB = CreateFrame("CheckButton", nil, p, "UICheckButtonTemplate")
    enCB:SetWidth(20); enCB:SetHeight(20)
    enCB:SetPoint("TOPLEFT", p, "TOPLEFT", 272, -44)
    local enL = p:CreateFontString(nil, "OVERLAY")
    enL:SetFont(FONT, 10, "OUTLINE"); enL:SetTextColor(0.9, 0.85, 0.7, 1)
    enL:SetPoint("LEFT", enCB, "RIGHT", 2, 0); enL:SetText("Enabled")
    enCB:SetScript("OnClick", function()
        local db = Floater_GetDB()
        if db and db.groups and db.groups[S.activeGroup] then
            db.groups[S.activeGroup].enabled = (this:GetChecked() == 1)
        end
    end)
    p._enCB = enCB

    mkLbl(p, "Position  X:", 14, -70, 10)
    local xEB = mkEB(p, 50, 18, 90, -68, 5)
    mkLbl(p, "Y:", 148, -70, 10)
    local yEB = mkEB(p, 50, 18, 162, -68, 5)
    local posBtn = mkBtn(p, "Apply", 70, 20, 222, -67)
    posBtn:SetScript("OnClick", function()
        local db = Floater_GetDB()
        if db and db.groups and db.groups[S.activeGroup] then
            local x = tonumber(xEB:GetText())
            local y = tonumber(yEB:GetText())
            if x and y then
                db.groups[S.activeGroup].x = x
                db.groups[S.activeGroup].y = y
                Floater_UpdateGroupPos(S.activeGroup)
            end
        end
    end)
    local testGrpBtn = mkBtn(p, "Test", 55, 20, 302, -67)
    testGrpBtn:SetScript("OnClick", function() Floater_TestGroup(S.activeGroup) end)
    p._xEB = xEB; p._yEB = yEB

    mkSep(p, 8, -94, 400)
    mkLbl(p, "Assign Text Types to this Group:", 14, -104, 11, 1, 0.82, 0.28)
    mkLbl(p, "A type can only belong to one group at a time.", 14, -117, 9, 0.55, 0.55, 0.55)

    local sf = CreateFrame("ScrollFrame", "FloaterGroupTypeScroll", p, "UIPanelScrollFrameTemplate")
    sf:SetWidth(370); sf:SetHeight(180)
    sf:SetPoint("TOPLEFT", p, "TOPLEFT", 10, -132)

    local content = CreateFrame("Frame", nil, sf)
    content:SetWidth(370)
    content:SetHeight(math.ceil(table.getn(FloaterTypes)/2) * 24)
    sf:SetScrollChild(content)

    local typeCBs = {}
    for i, td in ipairs(FloaterTypes) do
        -- snapshot loop vars
        local tdKey   = td.key
        local tdR     = td.r
        local tdG     = td.g
        local tdB     = td.b
        local tdLabel = td.label

        local col  = math.mod(i-1, 2)
        local row  = math.floor((i-1) / 2)
        local xOff = col * 185
        local yOff = -row * 24

        if math.mod(row, 2) == 0 then
            local bg = content:CreateTexture(nil, "BACKGROUND")
            bg:SetWidth(370); bg:SetHeight(24)
            bg:SetPoint("TOPLEFT", content, "TOPLEFT", 0, yOff)
            bg:SetTexture(0.08, 0.07, 0.12, 0.5)
        end

        local cb = CreateFrame("CheckButton", nil, content, "UICheckButtonTemplate")
        cb:SetWidth(18); cb:SetHeight(18)
        cb:SetPoint("TOPLEFT", content, "TOPLEFT", xOff+2, yOff-3)
        cb._key = tdKey

        local lbl2 = content:CreateFontString(nil, "OVERLAY")
        lbl2:SetFont(FONT, 10, "OUTLINE")
        lbl2:SetTextColor(tdR, tdG, tdB, 1)
        lbl2:SetPoint("LEFT", cb, "RIGHT", 2, 0)
        lbl2:SetText(tdLabel)

        cb:SetScript("OnClick", function()
            local db = Floater_GetDB()
            if not db or not db.groups then return end
            local checked = (this:GetChecked() == 1)
            local key = this._key
            if checked then
                for gi2 = 1, MAX_GROUPS do
                    if db.groups[gi2] and db.groups[gi2].types then
                        db.groups[gi2].types[key] = nil
                    end
                end
                db.groups[S.activeGroup].types[key] = true
            else
                if db.groups[S.activeGroup] and db.groups[S.activeGroup].types then
                    db.groups[S.activeGroup].types[key] = nil
                end
            end
            if Floater_RebuildTypeToGroup then Floater_RebuildTypeToGroup() end
            S:refreshGroupTypeCBs()
        end)
        typeCBs[tdKey] = cb
    end
    p._typeCBs = typeCBs
    return p
end

-------------------------------------------------------------------------------
-- TAB 3 — TEXT TYPES  (with color wheel swatch)
-------------------------------------------------------------------------------
local ROW_H   = 26
local VISIBLE = 10

local function buildTypesTab(parent)
    local p = CreateFrame("Frame", nil, parent)
    p:SetAllPoints(parent); p:Hide()

    mkLbl(p, "Type",       14,  -8, 10, 1, 0.82, 0.28)
    mkLbl(p, "On",        220,  -8, 10, 1, 0.82, 0.28)
    mkLbl(p, "Color",     244,  -8, 10, 1, 0.82, 0.28)
    mkLbl(p, "Size",      332,  -8, 10, 1, 0.82, 0.28)
    mkLbl(p, "Group",     360,  -8, 10, 1, 0.82, 0.28)
    mkSep(p, 10, -20, 395)

    local sf = CreateFrame("ScrollFrame", "FloaterTypeScroll2", p, "UIPanelScrollFrameTemplate")
    sf:SetWidth(395); sf:SetHeight(ROW_H * VISIBLE)
    sf:SetPoint("TOPLEFT", p, "TOPLEFT", 8, -24)

    local content = CreateFrame("Frame", nil, sf)
    content:SetWidth(395); content:SetHeight(ROW_H * table.getn(FloaterTypes))
    sf:SetScrollChild(content)

    S.typeRows = {}
    for i, td in ipairs(FloaterTypes) do
        -- Snapshot loop vars into true locals so closures capture the right values
        local tdKey    = td.key
        local tdLabel  = td.label
        local tdSample = td.sample
        local tdR      = td.r
        local tdG      = td.g
        local tdB      = td.b
        local tdIsCrit = (td.key == "OUT_CRIT" or td.key == "IN_CRIT" or td.key == "HEAL_CRIT")

        local yOff = -((i-1) * ROW_H)
        local row  = {}

        -- stripe
        local bg = content:CreateTexture(nil, "BACKGROUND")
        bg:SetWidth(393); bg:SetHeight(ROW_H - 2)
        bg:SetPoint("TOPLEFT", content, "TOPLEFT", 0, yOff)
        if math.mod(i, 2) == 0 then bg:SetTexture(0.10, 0.09, 0.14, 0.6)
        else                         bg:SetTexture(0.07, 0.06, 0.10, 0.4) end

        -- Label
        local labelFS = content:CreateFontString(nil, "OVERLAY")
        labelFS:SetFont(FONT, 11, "OUTLINE")
        labelFS:SetTextColor(tdR, tdG, tdB, 1)
        labelFS:SetPoint("TOPLEFT", content, "TOPLEFT", 4, yOff - 6)
        labelFS:SetText(tdLabel)
        row.labelFS = labelFS

        -- Enable checkbox
        local cb = CreateFrame("CheckButton", nil, content, "UICheckButtonTemplate")
        cb:SetWidth(18); cb:SetHeight(18)
        cb:SetPoint("TOPLEFT", content, "TOPLEFT", 208, yOff - 4)
        cb._key = tdKey
        cb:SetScript("OnClick", function()
            local db = Floater_GetDB()
            if db and db.types and db.types[this._key] then
                db.types[this._key].enabled = (this:GetChecked() == 1)
            end
        end)
        row.cb = cb

        -- ── Color swatch button (opens color wheel) ───────────────────────
        local swBtn = CreateFrame("Button", nil, content)
        swBtn:SetWidth(60); swBtn:SetHeight(16)
        swBtn:SetPoint("TOPLEFT", content, "TOPLEFT", 230, yOff - 5)
        local swBorder = swBtn:CreateTexture(nil, "BACKGROUND")
        swBorder:SetAllPoints(swBtn); swBorder:SetTexture(0.3, 0.3, 0.3, 1)
        local swInner = CreateFrame("Frame", nil, swBtn)
        swInner:SetPoint("TOPLEFT", swBtn, "TOPLEFT", 1, -1)
        swInner:SetPoint("BOTTOMRIGHT", swBtn, "BOTTOMRIGHT", -1, 1)
        local swTex = swInner:CreateTexture(nil, "ARTWORK")
        swTex:SetAllPoints(swInner); swTex:SetTexture(tdR, tdG, tdB, 1)
        row.swatch = swTex
        row.swBtn  = swBtn

        swBtn._key = tdKey
        swBtn._row = row
        swBtn:SetScript("OnClick", function()
            local db = Floater_GetDB()
            local tc = db and db.types and db.types[this._key]
            local r2, g2, b2 = tdR, tdG, tdB
            if tc then r2, g2, b2 = tc.r, tc.g, tc.b end
            local key    = this._key
            local rowRef = this._row
            CW:open(r2, g2, b2, function(nr, ng, nb)
                local db2 = Floater_GetDB()
                if db2 and db2.types and db2.types[key] then
                    db2.types[key].r = nr
                    db2.types[key].g = ng
                    db2.types[key].b = nb
                end
                rowRef.swatch:SetTexture(nr, ng, nb, 1)
                rowRef.labelFS:SetTextColor(nr, ng, nb, 1)
            end, swBtn)
        end)
        swBtn:SetScript("OnEnter", function()
            local db = Floater_GetDB()
            local tc = db and db.types and db.types[this._key]
            local r2, g2, b2 = tdR, tdG, tdB
            if tc then r2, g2, b2 = tc.r, tc.g, tc.b end
            GameTooltip:SetOwner(this, "ANCHOR_RIGHT")
            GameTooltip:SetText("#"..toHex(r2, g2, b2), r2, g2, b2)
            GameTooltip:Show()
        end)
        swBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)

        -- Size editbox
        local sizeEB = mkEB(content, 30, 18, 298, yOff - 5, 3)
        sizeEB._key = tdKey
        local function applySize(eb)
            local db = Floater_GetDB()
            if db and db.types and db.types[eb._key] then
                db.types[eb._key].fontSize = tonumber(eb:GetText()) or 0
            end
        end
        sizeEB:SetScript("OnEnterPressed", function() applySize(this); this:ClearFocus() end)
        sizeEB:SetScript("OnEditFocusLost", function() applySize(this) end)
        row.sizeEB = sizeEB

        -- Group label
        local grpLbl = content:CreateFontString(nil, "OVERLAY")
        grpLbl:SetFont(FONT, 10, "OUTLINE"); grpLbl:SetTextColor(0.70, 0.70, 0.50, 1)
        grpLbl:SetPoint("TOPLEFT", content, "TOPLEFT", 338, yOff - 6)
        grpLbl:SetText("—")
        row.grpLbl = grpLbl

        -- Preview button
        local pBtn = CreateFrame("Button", nil, content)
        pBtn:SetWidth(18); pBtn:SetHeight(18)
        pBtn:SetPoint("TOPLEFT", content, "TOPLEFT", 374, yOff - 5)
        local pTex = pBtn:CreateFontString(nil, "OVERLAY")
        pTex:SetFont(FONT, 12, "OUTLINE"); pTex:SetAllPoints(pBtn)
        pTex:SetJustifyH("CENTER"); pTex:SetText("▶")
        pTex:SetTextColor(0.5, 0.8, 0.5, 1)
        pBtn._key    = tdKey
        pBtn._sample = tdSample
        pBtn._isCrit = tdIsCrit
        pBtn:SetScript("OnClick", function()
            Floater_TestSpawnKey(this._key, this._sample, this._isCrit)
        end)
        pBtn:SetScript("OnEnter", function()
            GameTooltip:SetOwner(this, "ANCHOR_RIGHT")
            GameTooltip:SetText("Preview", 1, 1, 1); GameTooltip:Show()
        end)
        pBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
        row.pBtn = pBtn

        S.typeRows[tdKey] = row
    end
    return p
end

-------------------------------------------------------------------------------
-- TAB 4 — BOOM
-------------------------------------------------------------------------------
local function buildBoomTab(parent)
    local p = CreateFrame("Frame", nil, parent)
    p:SetAllPoints(parent); p:Hide()

    -- Title / description
    mkLbl(p, "BOOM SYSTEM", 14, -10, 13, 1, 0.40, 0.10)
    mkLbl(p, "Yell in chat when you land big crits or crit streaks.", 14, -26, 10, 0.70, 0.65, 0.55)

    mkSep(p, 10, -42, 400)

    -- Master enable
    local enCB = CreateFrame("CheckButton", nil, p, "UICheckButtonTemplate")
    enCB:SetWidth(22); enCB:SetHeight(22)
    enCB:SetPoint("TOPLEFT", p, "TOPLEFT", 14, -52)
    local enL = p:CreateFontString(nil, "OVERLAY")
    enL:SetFont(FONT, 12, "OUTLINE"); enL:SetTextColor(1, 0.82, 0.22, 1)
    enL:SetPoint("LEFT", enCB, "RIGHT", 4, 0); enL:SetText("Enable BOOM")
    enCB:SetScript("OnClick", function()
        local db = Floater_GetDB()
        if db and db.boom then
            db.boom.enabled = (this:GetChecked() == 1)
            -- keep Global tab checkbox in sync
            if S.panels[1] and S.panels[1]._boomCB then
                S.panels[1]._boomCB:SetChecked(db.boom.enabled and 1 or 0)
            end
        end
    end)
    p._enCB = enCB

    mkSep(p, 10, -82, 400)

    -- Single hit threshold
    mkLbl(p, "BIG HIT THRESHOLD", 14, -92, 11, 1, 0.82, 0.28)
    mkLbl(p, "Yell when a single crit exceeds this damage", 14, -105, 9, 0.55, 0.55, 0.55)
    local slThresh, vlThresh = mkSlider(p, 100, 5000, 100, 14, -122, 300, "100", "5000")
    slThresh:SetScript("OnValueChanged", function()
        local v = math.floor(this:GetValue() / 100) * 100
        vlThresh:SetText(tostring(v))
        local db = Floater_GetDB()
        if db and db.boom then db.boom.threshold = v end
    end)
    p._slThresh = slThresh; p._vlThresh = vlThresh

    mkSep(p, 10, -148, 400)

    -- Streak count
    mkLbl(p, "STREAK COUNT", 14, -158, 11, 1, 0.82, 0.28)
    mkLbl(p, "Yell when you land this many crits in a row", 14, -171, 9, 0.55, 0.55, 0.55)
    local slStreak, vlStreak = mkSlider(p, 2, 8, 1, 14, -188, 200, "2", "8")
    slStreak:SetScript("OnValueChanged", function()
        local v = math.floor(this:GetValue())
        vlStreak:SetText(tostring(v))
        local db = Floater_GetDB()
        if db and db.boom then db.boom.streakCount = v end
    end)
    p._slStreak = slStreak; p._vlStreak = vlStreak

    mkSep(p, 10, -214, 400)

    -- Streak window
    mkLbl(p, "STREAK WINDOW  (seconds)", 14, -224, 11, 1, 0.82, 0.28)
    mkLbl(p, "Crits must land within this time to count as a streak", 14, -237, 9, 0.55, 0.55, 0.55)
    local slWindow, vlWindow = mkSlider(p, 2, 20, 1, 14, -254, 200, "2", "20")
    slWindow:SetScript("OnValueChanged", function()
        local v = math.floor(this:GetValue())
        vlWindow:SetText(tostring(v).."s")
        local db = Floater_GetDB()
        if db and db.boom then db.boom.streakWindow = v end
    end)
    p._slWindow = slWindow; p._vlWindow = vlWindow

    mkSep(p, 10, -280, 400)

    -- Preview
    mkLbl(p, "PREVIEW", 14, -290, 11, 1, 0.82, 0.28)
    local testBigBtn = mkBtn(p, "Test Big Hit", 100, 22, 14, -306)
    testBigBtn:SetScript("OnClick", function()
        if Floater_TestBoom then Floater_TestBoom() end
    end)
    local testStreakBtn = mkBtn(p, "Test Streak", 100, 22, 124, -306)
    testStreakBtn:SetScript("OnClick", function()
        if Floater_TestBoomStreak then Floater_TestBoomStreak() end
    end)
    mkLbl(p, "Both buttons will yell in chat if BOOM is enabled.", 14, -334, 9, 0.50, 0.50, 0.50)

    return p
end

-------------------------------------------------------------------------------
-- BUILD MAIN FRAME
-------------------------------------------------------------------------------
local function buildFrame()
    if S.frame then return end
    local W, H = 420, 390

    local f = CreateFrame("Frame", "FloaterSettingsFrame", UIParent)
    f:SetWidth(W); f:SetHeight(H)
    f:SetPoint("CENTER", UIParent, "CENTER", 0, 60)
    f:SetFrameStrata("DIALOG")
    f:SetMovable(true); f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", function() this:StartMoving() end)
    f:SetScript("OnDragStop",  function() this:StopMovingOrSizing() end)
    applyBackdrop(f)

    local title = f:CreateFontString(nil, "OVERLAY")
    title:SetFont(FONT, 14, "OUTLINE"); title:SetTextColor(1, 0.78, 0.22, 1)
    title:SetPoint("TOP", f, "TOP", 0, -10); title:SetText("Floater  —  Settings")

    local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", f, "TOPRIGHT", 2, 2)
    close:SetScript("OnClick", function() S.frame:Hide() end)

    local TAB_NAMES = {"Global", "Groups", "Text Types", "Boom"}
    local tabW = (W - 20) / 4
    for i, name in ipairs(TAB_NAMES) do
        local tb = CreateFrame("Button", nil, f)
        tb:SetWidth(tabW); tb:SetHeight(22)
        tb:SetPoint("TOPLEFT", f, "TOPLEFT", 10 + (i-1)*tabW, -28)
        local bg = tb:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints(tb); bg:SetTexture(0.10, 0.08, 0.06, 0); tb._bg = bg
        local tl = tb:CreateFontString(nil, "OVERLAY")
        tl:SetFont(FONT, 11, "OUTLINE"); tl:SetAllPoints(tb)
        tl:SetJustifyH("CENTER"); tl:SetText(name)
        tl:SetTextColor(0.75, 0.70, 0.60, 1); tb._lbl = tl; tb._idx = i
        tb:SetScript("OnClick", function() S:switchTab(this._idx) end)
        tb:SetScript("OnEnter", function()
            if S.activeTab ~= this._idx then this._bg:SetTexture(0.20, 0.16, 0.10, 0.6) end
        end)
        tb:SetScript("OnLeave", function()
            if S.activeTab ~= this._idx then this._bg:SetTexture(0.10, 0.08, 0.06, 0) end
        end)
        S.tabs[i] = tb
    end

    local content = CreateFrame("Frame", nil, f)
    content:SetWidth(W - 10); content:SetHeight(H - 52)
    content:SetPoint("TOPLEFT", f, "TOPLEFT", 5, -52)

    S.panels[1] = buildGlobalTab(content)
    S.panels[2] = buildGroupsTab(content)
    S.panels[3] = buildTypesTab(content)
    S.panels[4] = buildBoomTab(content)
    S.frame = f; f:Hide()
end

-------------------------------------------------------------------------------
-- REFRESH
-------------------------------------------------------------------------------
function S:refreshGlobal()
    local db = Floater_GetDB(); if not db then return end
    local p = self.panels[1]
    p._slFS:SetValue(db.fontSize or 22); p._vlFS:SetText(tostring(db.fontSize or 22))
    local dt = math.floor((db.duration or 1.8) * 10)
    p._slDur:SetValue(dt); p._vlDur:SetText(string.format("%.1f", (db.duration or 1.8)))
    p._slDist:SetValue(db.floatDist or 60); p._vlDist:SetText(tostring(db.floatDist or 60))
    local spd = math.floor((db.floatSpeed or 1.0) * 10)
    p._slSpeed:SetValue(spd); p._vlSpeed:SetText(string.format("%.1f", (db.floatSpeed or 1.0)))
    p._stagCB:SetChecked((db.stagger ~= false) and 1 or 0)
    p._enCB:SetChecked(db.enabled and 1 or 0)
    if p._boomCB and db.boom then
        p._boomCB:SetChecked(db.boom.enabled and 1 or 0)
    end
end

function S:refreshGroupTabLabels()
    local db = Floater_GetDB(); if not db then return end
    local p = self.panels[2]; if not p._groupTabBtns then return end
    for gi = 1, MAX_GROUPS do
        local tb = p._groupTabBtns[gi]
        if tb then
            local gname = (db.groups and db.groups[gi] and db.groups[gi].name) or ("Group "..gi)
            local short = string.sub(gname, 1, 9)
            if string.len(gname) > 9 then short = short..".." end
            tb._lbl:SetText(short)
            if gi == self.activeGroup then
                tb._bg:SetTexture(0.28, 0.20, 0.08, 0.9)
                tb._lbl:SetTextColor(1, 0.85, 0.30, 1)
            else
                tb._bg:SetTexture(0.10, 0.08, 0.06, 0)
                tb._lbl:SetTextColor(0.75, 0.70, 0.60, 1)
            end
        end
    end
end

function S:refreshGroupTypeCBs()
    local db = Floater_GetDB(); if not db or not db.groups then return end
    local p = self.panels[2]; if not p._typeCBs then return end
    local g = db.groups[self.activeGroup]
    for _, td in ipairs(FloaterTypes) do
        local cb = p._typeCBs[td.key]
        if cb then
            local owned = (g and g.types and g.types[td.key])
            cb:SetChecked(owned and 1 or 0)
        end
    end
end

function S:refreshGroupsTab()
    local db = Floater_GetDB(); if not db or not db.groups then return end
    local p = self.panels[2]
    local g = db.groups[self.activeGroup]; if not g then return end
    self:refreshGroupTabLabels()
    p._nameEB:SetText(g.name or ("Group "..self.activeGroup))
    p._enCB:SetChecked(g.enabled and 1 or 0)
    p._xEB:SetText(tostring(g.x or 0))
    p._yEB:SetText(tostring(g.y or -100))
    self:refreshGroupTypeCBs()
end

function S:refreshTypes()
    local db = Floater_GetDB(); if not db or not db.types then return end
    local typeGroupName = {}
    if db.groups then
        for gi = 1, MAX_GROUPS do
            local g = db.groups[gi]
            if g and g.types then
                for typeKey, _ in pairs(g.types) do
                    typeGroupName[typeKey] = string.sub(g.name or ("G"..gi), 1, 6)
                end
            end
        end
    end
    for _, td in ipairs(FloaterTypes) do
        local tc  = db.types[td.key]
        local row = self.typeRows[td.key]
        if tc and row then
            row.cb:SetChecked(tc.enabled and 1 or 0)
            row.swatch:SetTexture(tc.r, tc.g, tc.b, 1)
            row.labelFS:SetTextColor(tc.r, tc.g, tc.b, 1)
            row.sizeEB:SetText((tc.fontSize and tc.fontSize > 0) and tostring(tc.fontSize) or "0")
            row.grpLbl:SetText(typeGroupName[td.key] or "—")
        end
    end
end

function S:refreshBoom()
    local db = Floater_GetDB(); if not db or not db.boom then return end
    local p = self.panels[4]; if not p then return end
    local boom = db.boom
    p._enCB:SetChecked(boom.enabled and 1 or 0)
    local thresh = boom.threshold or 1000
    p._slThresh:SetValue(thresh); p._vlThresh:SetText(tostring(thresh))
    local sc = boom.streakCount or 3
    p._slStreak:SetValue(sc); p._vlStreak:SetText(tostring(sc))
    local sw = boom.streakWindow or 8
    p._slWindow:SetValue(sw); p._vlWindow:SetText(tostring(sw).."s")
end

function S:refreshAll()
    self:refreshGlobal()
    self:refreshGroupsTab()
    self:refreshTypes()
    self:refreshBoom()
end

-------------------------------------------------------------------------------
-- TAB SWITCHER
-------------------------------------------------------------------------------
function S:switchTab(idx)
    self.activeTab = idx
    for i, p in ipairs(self.panels) do
        if i == idx then p:Show() else p:Hide() end
    end
    for i, tb in ipairs(self.tabs) do
        if i == idx then
            tb._bg:SetTexture(0.28, 0.20, 0.08, 0.9)
            tb._lbl:SetTextColor(1, 0.85, 0.30, 1)
        else
            tb._bg:SetTexture(0.10, 0.08, 0.06, 0)
            tb._lbl:SetTextColor(0.75, 0.70, 0.60, 1)
        end
    end
    if idx == 1 then self:refreshGlobal()    end
    if idx == 2 then self:refreshGroupsTab() end
    if idx == 3 then self:refreshTypes()     end
    if idx == 4 then self:refreshBoom()      end
end

-------------------------------------------------------------------------------
-- PUBLIC
-------------------------------------------------------------------------------
function FloaterSettings_Toggle()
    if not S.frame then buildFrame() end
    if S.frame:IsShown() then
        S.frame:Hide()
    else
        S:switchTab(S.activeTab)
        S.frame:Show()
    end
end

function FloaterSettings_RefreshGroups()
    if S.frame and S.frame:IsShown() and S.activeTab == 2 then
        S:refreshGroupsTab()
    end
end
