-------------------------------------------------------------------------------
-- Floater.lua  v4.0
-- Custom floating combat text with up to 4 independent groups
-- Each group has its own screen position, and text types are assigned to groups
-- Turtle WoW / WoW 1.12
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
-- TEXT TYPE DEFINITIONS
-------------------------------------------------------------------------------
FloaterTypes = {
    { key="OUT_PHYS",   label="Outgoing Melee",    sample="243",         r=1.00, g=1.00, b=1.00 },
    { key="OUT_SPELL",  label="Outgoing Spell",    sample="543",         r=1.00, g=0.60, b=0.10 },
    { key="OUT_CRIT",   label="Outgoing Crit",     sample="1086!",       r=1.00, g=0.90, b=0.00 },
    { key="OUT_DOT",    label="DoT Tick (Out)",    sample="88",          r=1.00, g=0.55, b=0.05 },
    { key="MISS",       label="Miss/Dodge/Parry",  sample="Miss",        r=0.65, g=0.65, b=0.65 },
    { key="IN_PHYS",    label="Incoming Melee",    sample="-312",        r=0.90, g=0.20, b=0.20 },
    { key="IN_SPELL",   label="Incoming Spell",    sample="-200",        r=0.85, g=0.35, b=0.85 },
    { key="IN_CRIT",    label="Incoming Crit",     sample="-624!",       r=1.00, g=0.30, b=0.10 },
    { key="IN_DOT",     label="DoT Tick (In)",     sample="-88",         r=0.80, g=0.25, b=0.80 },
    { key="HEAL",       label="Heal",              sample="+540",        r=0.30, g=1.00, b=0.45 },
    { key="HEAL_CRIT",  label="Crit Heal",         sample="+1080!",      r=0.10, g=1.00, b=0.60 },
    { key="HOT",        label="HoT Tick",          sample="+120",        r=0.20, g=0.90, b=0.40 },
    { key="MANA",       label="Mana Regen",        sample="+50 mana",    r=0.30, g=0.55, b=1.00 },
    { key="ENERGY",     label="Energy Regen",      sample="+20 energy",  r=1.00, g=0.90, b=0.20 },
    { key="RAGE",       label="Rage Regen",        sample="+10 rage",    r=1.00, g=0.30, b=0.20 },
    { key="BUFF",       label="Buff Gained",       sample="+Arcane Int", r=0.40, g=1.00, b=0.55 },
    { key="BUFF_GONE",  label="Buff Faded",        sample="Haste faded", r=0.70, g=0.70, b=0.70 },
    { key="XP",         label="XP Gain",           sample="+320 XP",     r=0.80, g=0.80, b=0.20 },
    { key="HONOR",      label="Honor Gain",        sample="+124 Honor",  r=0.95, g=0.25, b=0.25 },
}

-- Quick lookup: typeKey -> index in FloaterTypes
FloaterTypeIndex = {}
for i, td in ipairs(FloaterTypes) do FloaterTypeIndex[td.key] = i end

MAX_GROUPS = 4

-------------------------------------------------------------------------------
-- DEFAULT GROUP CONFIGS
-- Each group: name, x, y, enabled, types = { typeKey=true, ... }
-------------------------------------------------------------------------------
local function defaultGroups()
    return {
        {
            name    = "Outgoing",
            x       = 180, y = -160,
            enabled = true,
            types   = { OUT_PHYS=true, OUT_SPELL=true, OUT_CRIT=true, OUT_DOT=true, MISS=true },
        },
        {
            name    = "Incoming",
            x       = -180, y = -160,
            enabled = true,
            types   = { IN_PHYS=true, IN_SPELL=true, IN_CRIT=true, IN_DOT=true },
        },
        {
            name    = "Healing",
            x       = 0, y = -80,
            enabled = true,
            types   = { HEAL=true, HEAL_CRIT=true, HOT=true, MANA=true, ENERGY=true, RAGE=true },
        },
        {
            name    = "Buffs & XP",
            x       = 0, y = -260,
            enabled = true,
            types   = { BUFF=true, BUFF_GONE=true, XP=true, HONOR=true },
        },
    }
end

-------------------------------------------------------------------------------
-- DEFAULTS
-------------------------------------------------------------------------------
FloaterDefaults = {
    fontSize   = 22,
    duration   = 1.8,
    floatDist  = 60,
    floatSpeed = 1.0,   -- speed multiplier: 0.5 = slow, 2.0 = fast
    stagger    = true,  -- alternate left/right each spawn per group
    enabled    = true,
    types      = {},
    groups     = {},
    boom       = {
        enabled       = true,
        threshold     = 1000,
        streakCount   = 3,
        streakWindow  = 8,
    },
}

local function buildTypeDefaults()
    local t = {}
    for _, td in ipairs(FloaterTypes) do
        t[td.key] = { enabled=true, r=td.r, g=td.g, b=td.b, fontSize=0 }
    end
    return t
end

-------------------------------------------------------------------------------
-- RUNTIME STATE
-------------------------------------------------------------------------------
MT            = {}
MT.pools      = {}      -- per-group pool:  MT.pools[groupIdx] = { entries }
MT.active     = {}      -- all active entries across all groups
MT.anchors    = {}      -- per-group anchor frames: MT.anchors[groupIdx]
MT.stagger    = {}      -- per-group flip flag for L/R stagger: MT.stagger[gi] = 1 or -1
MT.eventFrame = nil

local db

-- Build a lookup: typeKey -> groupIndex (first group that owns that type)
local typeToGroup = {}

local function rebuildTypeToGroup()
    -- Clear in place — do NOT reassign the variable, closures hold a ref to this table
    for k in pairs(typeToGroup) do typeToGroup[k] = nil end
    if not db or not db.groups then return end
    for gi = 1, table.getn(db.groups) do
        local g = db.groups[gi]
        if g and g.types then
            for typeKey, _ in pairs(g.types) do
                if not typeToGroup[typeKey] then
                    typeToGroup[typeKey] = gi
                end
            end
        end
    end
end

-------------------------------------------------------------------------------
-- BOOM SYSTEM  — yell on big crits and crit streaks
-------------------------------------------------------------------------------
local BOOM = {}
BOOM.streakCount  = 0
BOOM.lastCritTime = -999   -- large negative so first crit always starts a fresh streak

local function boomYell(msg)
    pcall(SendChatMessage, msg, "YELL")
end

local function boomBuildMsg(count)
    local msg = "BOOM"
    for j = 2, count do
        msg = msg.." BOOM"
    end
    return msg
end

-- Called every time a player outgoing crit lands
-- amt: numeric damage value
local function boomOnCrit(amt)
    if not db or not db.boom then return end
    local boom = db.boom
    if not boom.enabled then return end

    local now     = GetTime()
    local window  = boom.streakWindow or 8
    local thresh  = boom.threshold    or 1000
    local streakN = boom.streakCount  or 3

    -- Update streak counter
    if now - BOOM.lastCritTime <= window then
        BOOM.streakCount = BOOM.streakCount + 1
    else
        BOOM.streakCount = 1   -- window expired, start fresh
    end
    BOOM.lastCritTime = now

    -- Streak yell — fires each time count hits exactly the target (and every one above)
    if BOOM.streakCount >= streakN then
        boomYell(boomBuildMsg(streakN))
        return   -- streak takes priority
    end

    -- Single big hit — just yell BOOM once
    if amt >= thresh then
        boomYell("BOOM")
    end
end

-------------------------------------------------------------------------------
-- SUPPRESS / RESTORE DEFAULT FCT
-------------------------------------------------------------------------------
local FCT_CVARS = {
    "floatingCombatTextCombatDamage",
    "floatingCombatTextCombatHealing",
    "floatingCombatTextCombatLogPeriodicSpells",
    "floatingCombatTextPetMeleeDamage",
    "floatingCombatTextPetSpellDamage",
    "floatingCombatTextDodgeParryMiss",
    "floatingCombatTextRepChanges",
    "floatingCombatTextReactive",
    "floatingCombatTextEnergyGains",
    "floatingCombatTextHonorGains",
    "floatingCombatTextFriendlyHealers",
}
local function safeCVar(n,v) pcall(SetCVar,n,v) end
local function suppressDefaultFCT()
    for _, cv in ipairs(FCT_CVARS) do safeCVar(cv, "0") end
    if CombatText and CombatText.Hide then CombatText:Hide() end
    if CombatTextOverlay and CombatTextOverlay.Hide then CombatTextOverlay:Hide() end
end
local function restoreDefaultFCT()
    for _, cv in ipairs(FCT_CVARS) do safeCVar(cv, "1") end
end

-------------------------------------------------------------------------------
-- GROUP ANCHOR FRAMES
-------------------------------------------------------------------------------
local function buildAnchors()
    for gi = 1, MAX_GROUPS do
        if not MT.anchors[gi] then
            local f = CreateFrame("Frame", "FloaterAnchor"..gi, UIParent)
            f:SetWidth(80); f:SetHeight(24)
            -- MEDIUM strata: always below text (TOOLTIP) so it never eats clicks or overlaps
            f:SetFrameStrata("MEDIUM")
            f:SetMovable(true)
            f:EnableMouse(false)
            f:RegisterForDrag("LeftButton")
            f:SetScript("OnDragStart", function() this:StartMoving() end)
            f:SetScript("OnDragStop", function()
                this:StopMovingOrSizing()
                -- GetPoint after StopMoving returns TOPLEFT offset from UIParent —
                -- we need CENTER offset from screen center, so use GetCenter instead.
                local cx, cy = this:GetCenter()
                local sw, sh = GetScreenWidth(), GetScreenHeight()
                local scale  = this:GetEffectiveScale()
                -- GetCenter returns values in the frame's own scale; convert to UIParent scale
                local nx = math.floor(cx - (sw / scale) / 2)
                local ny = math.floor(cy - (sh / scale) / 2)
                if db and db.groups and db.groups[this._gi] then
                    db.groups[this._gi].x = nx
                    db.groups[this._gi].y = ny
                end
                -- Re-anchor cleanly so subsequent spawns use the right position
                this:ClearAllPoints()
                this:SetPoint("CENTER", UIParent, "CENTER", nx, ny)
                if FloaterSettings_RefreshGroups then FloaterSettings_RefreshGroups() end
            end)
            f._gi = gi

            local lbl = f:CreateFontString(nil, "OVERLAY")
            lbl:SetFont("Fonts\\FRIZQT__.TTF", 9, "OUTLINE")
            lbl:SetTextColor(0, 0, 0, 0)   -- hidden until unlocked
            lbl:SetPoint("TOP", f, "TOP", 0, 0)
            lbl:SetText("Group "..gi)
            f._lbl = lbl

            local box = f:CreateTexture(nil, "BACKGROUND")
            box:SetAllPoints(f)
            box:SetTexture(0, 0, 0, 0)
            f._box = box

            MT.anchors[gi] = f
        end
    end
end

local function updateAnchorPositions()
    if not db or not db.groups then return end
    for gi = 1, MAX_GROUPS do
        local f = MT.anchors[gi]
        local g = db.groups[gi]
        if f and g then
            f:ClearAllPoints()
            f:SetPoint("CENTER", UIParent, "CENTER", g.x or 0, g.y or -100)
            f._lbl:SetText(g.name or ("Group "..gi))
        end
    end
end

local function setGroupsLocked(locked)
    for gi = 1, MAX_GROUPS do
        local f = MT.anchors[gi]
        if f then
            if locked then
                f:EnableMouse(false)
                f._box:SetTexture(0,0,0,0)
                f._lbl:SetTextColor(0, 0, 0, 0)   -- hide label when locked
            else
                f:EnableMouse(true)
                f._box:SetTexture(0.10, 0.10, 0.20, 0.55)
                f._lbl:SetTextColor(1, 0.85, 0.25, 1)  -- show label when unlocked
            end
        end
    end
    -- re-suppress default FCT each time — chat messages can re-enable CVars
    if db and db.enabled then suppressDefaultFCT() end
end

-------------------------------------------------------------------------------
-- TEXT POOL (per-group)
-------------------------------------------------------------------------------
local FONT_PATH = "Fonts\\FRIZQT__.TTF"

local function acquireEntry(gi)
    if not MT.pools[gi] then MT.pools[gi] = {} end
    local pool = MT.pools[gi]
    for i = 1, table.getn(pool) do
        local e = pool[i]
        if not e.active then
            e.active = true; e.frame:Show(); return e
        end
    end
    local f  = CreateFrame("Frame", nil, UIParent)
    f:SetWidth(200); f:SetHeight(40); f:SetFrameStrata("TOOLTIP")
    local fs = f:CreateFontString(nil, "OVERLAY")
    fs:SetFont(FONT_PATH, 22, "OUTLINE")
    fs:SetPoint("CENTER", f, "CENTER", 0, 0)
    local entry = { frame=f, fs=fs, active=true, elapsed=0, startY=0, gi=gi }
    table.insert(pool, entry)
    return entry
end

local function releaseEntry(e)
    e.frame:Hide(); e.active=false; e.elapsed=0
end

-------------------------------------------------------------------------------
-- SPAWN
-------------------------------------------------------------------------------
local function spawnText(typeKey, text, isCrit)
    if not db or not db.enabled then return end
    local tc = db.types and db.types[typeKey]
    if tc and not tc.enabled then return end
    local gi = typeToGroup[typeKey]
    if not gi then return end
    local g = db.groups and db.groups[gi]
    if not g or not g.enabled then return end
    local anchor = MT.anchors[gi]
    if not anchor then return end

    -- resolve color
    local r, g2, b = 1, 1, 1
    if tc then r, g2, b = tc.r, tc.g, tc.b end

    -- resolve size
    local size = db.fontSize or 22
    if tc and tc.fontSize and tc.fontSize > 0 then size = tc.fontSize end
    if isCrit then size = math.floor(size * 1.45) end

    local e = acquireEntry(gi)
    e.fs:SetFont(FONT_PATH, size, "OUTLINE")
    e.fs:SetText(text)
    e.fs:SetTextColor(r, g2, b, 1)

    local gdata  = db.groups[gi]
    local baseX  = gdata.x or 0
    local baseY  = gdata.y or -100

    -- Stagger: flip left/right each spawn for this group
    local jitterSign = 1
    if db.stagger then
        if not MT.stagger[gi] then MT.stagger[gi] = 1 end
        jitterSign       = MT.stagger[gi]
        MT.stagger[gi]   = -MT.stagger[gi]
    end
    local jitter = math.random(8, 20) * jitterSign

    e.frame:ClearAllPoints()
    e.frame:SetPoint("CENTER", UIParent, "CENTER", baseX + jitter, baseY)
    e.frame:SetAlpha(1); e.frame:Show()

    e.elapsed    = 0
    e.duration   = db.duration   or 1.8
    e.floatDist  = db.floatDist  or 60
    e.floatSpeed = db.floatSpeed or 1.0
    e.startY     = baseY
    e.baseX      = baseX + jitter
    e.active     = true
    e.gi         = gi
    table.insert(MT.active, e)
end

-------------------------------------------------------------------------------
-- ONUPDATE
-------------------------------------------------------------------------------
local function onUpdate()
    local elapsed = arg1
    local i = 1
    while i <= table.getn(MT.active) do
        local e = MT.active[i]
        -- floatSpeed scales how fast the entry travels: higher = faster
        e.elapsed = e.elapsed + elapsed * (e.floatSpeed or 1.0)
        local frac = e.elapsed / e.duration
        if frac >= 1 then
            releaseEntry(e); table.remove(MT.active, i)
        else
            local newY = e.startY + (e.floatDist * frac)
            e.frame:ClearAllPoints()
            e.frame:SetPoint("CENTER", UIParent, "CENTER", e.baseX, newY)
            local alpha = 1
            if frac > 0.5 then alpha = 1 - ((frac - 0.5) / 0.5) end
            e.frame:SetAlpha(alpha)
            i = i + 1
        end
    end
end

-------------------------------------------------------------------------------
-- COMBAT PATTERNS
-------------------------------------------------------------------------------
local patterns = {}
local function addPat(evt, pat, fn)
    if not patterns[evt] then patterns[evt] = {} end
    table.insert(patterns[evt], { pat=pat, fn=fn })
end

-- Outgoing melee
addPat("CHAT_MSG_COMBAT_SELF_HITS", "^You hit .+ for (%d+)%.$",
    function(a) spawnText("OUT_PHYS", a, false) end)
addPat("CHAT_MSG_COMBAT_SELF_HITS", "^You crit .+ for (%d+)%.$",
    function(a) spawnText("OUT_CRIT", a.."!", true); boomOnCrit(tonumber(a) or 0) end)

-- Outgoing melee misses
addPat("CHAT_MSG_COMBAT_SELF_MISSES", "misses",   function() spawnText("MISS","Miss",false) end)
addPat("CHAT_MSG_COMBAT_SELF_MISSES", "dodges",   function() spawnText("MISS","Dodge",false) end)
addPat("CHAT_MSG_COMBAT_SELF_MISSES", "parries",  function() spawnText("MISS","Parry",false) end)
addPat("CHAT_MSG_COMBAT_SELF_MISSES", "blocks",   function() spawnText("MISS","Block",false) end)

-- Outgoing spell
addPat("CHAT_MSG_SPELL_SELF_DAMAGE", "^Your .+ hits .+ for (%d+)",
    function(a) spawnText("OUT_SPELL", a, false) end)
addPat("CHAT_MSG_SPELL_SELF_DAMAGE", "^Your .+ crits .+ for (%d+)",
    function(a) spawnText("OUT_CRIT", a.."!", true); boomOnCrit(tonumber(a) or 0) end)
addPat("CHAT_MSG_SPELL_SELF_DAMAGE", "^Your .+ misses",  function() spawnText("MISS","Miss",false) end)
addPat("CHAT_MSG_SPELL_SELF_DAMAGE", "is resisted",      function() spawnText("MISS","Resist",false) end)
addPat("CHAT_MSG_SPELL_SELF_DAMAGE", "was absorbed",     function() spawnText("MISS","Absorb",false) end)

-- Outgoing DoT
addPat("CHAT_MSG_SPELL_PERIODIC_CREATURE_DAMAGE", "^Your .+ hits .+ for (%d+)",
    function(a) spawnText("OUT_DOT", a, false) end)
addPat("CHAT_MSG_SPELL_PERIODIC_HOSTILEPLAYER_DAMAGE", "^Your .+ hits .+ for (%d+)",
    function(a) spawnText("OUT_DOT", a, false) end)

-- Incoming melee
addPat("CHAT_MSG_COMBAT_CREATURE_VS_SELF_HITS", "^.+ hits you for (%d+)%.$",
    function(a) spawnText("IN_PHYS","-"..a,false) end)
addPat("CHAT_MSG_COMBAT_CREATURE_VS_SELF_HITS", "^.+ crits you for (%d+)%.$",
    function(a) spawnText("IN_CRIT","-"..a.."!",true) end)
addPat("CHAT_MSG_COMBAT_HOSTILEPLAYER_HITS", "^.+ hits you for (%d+)%.$",
    function(a) spawnText("IN_PHYS","-"..a,false) end)
addPat("CHAT_MSG_COMBAT_HOSTILEPLAYER_HITS", "^.+ crits you for (%d+)%.$",
    function(a) spawnText("IN_CRIT","-"..a.."!",true) end)

-- Incoming melee misses
addPat("CHAT_MSG_COMBAT_CREATURE_VS_SELF_MISSES","misses you", function() spawnText("MISS","Miss",false) end)
addPat("CHAT_MSG_COMBAT_CREATURE_VS_SELF_MISSES","You dodge",  function() spawnText("MISS","Dodge",false) end)
addPat("CHAT_MSG_COMBAT_CREATURE_VS_SELF_MISSES","You parry",  function() spawnText("MISS","Parry",false) end)
addPat("CHAT_MSG_COMBAT_CREATURE_VS_SELF_MISSES","You block",  function() spawnText("MISS","Block",false) end)

-- Incoming spell
addPat("CHAT_MSG_SPELL_CREATURE_VS_SELF_DAMAGE","hits you for (%d+)",
    function(a) spawnText("IN_SPELL","-"..a,false) end)
addPat("CHAT_MSG_SPELL_CREATURE_VS_SELF_DAMAGE","crits you for (%d+)",
    function(a) spawnText("IN_CRIT","-"..a.."!",true) end)
addPat("CHAT_MSG_SPELL_CREATURE_VS_SELF_DAMAGE","was resisted", function() spawnText("MISS","Resist",false) end)
addPat("CHAT_MSG_SPELL_CREATURE_VS_SELF_DAMAGE","was absorbed", function() spawnText("MISS","Absorb",false) end)
addPat("CHAT_MSG_SPELL_HOSTILEPLAYER_DAMAGE","hits you for (%d+)",
    function(a) spawnText("IN_SPELL","-"..a,false) end)
addPat("CHAT_MSG_SPELL_HOSTILEPLAYER_DAMAGE","crits you for (%d+)",
    function(a) spawnText("IN_CRIT","-"..a.."!",true) end)

-- Incoming DoT
addPat("CHAT_MSG_SPELL_PERIODIC_SELF_DAMAGE","hits you for (%d+)",
    function(a) spawnText("IN_DOT","-"..a,false) end)

-- Heals from other players — capture healer name before 's
addPat("CHAT_MSG_SPELL_FRIENDLYPLAYER_BUFF","^(.+)'s .+ heals you for (%d+)%.$",
    function(a,b) spawnText("HEAL","+"..b.." ("..a..")",false) end)
addPat("CHAT_MSG_SPELL_FRIENDLYPLAYER_BUFF","^(.+)'s .+ critically heals you for (%d+)%.$",
    function(a,b) spawnText("HEAL_CRIT","+"..b.."! ("..a..")",true) end)
-- Fallback for any other friendly heal format without a name
addPat("CHAT_MSG_SPELL_FRIENDLYPLAYER_BUFF","heals you for (%d+)%.$",
    function(a) spawnText("HEAL","+"..a,false) end)
addPat("CHAT_MSG_SPELL_FRIENDLYPLAYER_BUFF","critically heals you for (%d+)%.$",
    function(a) spawnText("HEAL_CRIT","+"..a.."!",true) end)
addPat("CHAT_MSG_SPELL_SELF_BUFF","^Your .+ heals? you for (%d+)%.$",
    function(a) spawnText("HEAL","+"..a,false) end)
addPat("CHAT_MSG_SPELL_SELF_BUFF","^Your .+ critically heals? you for (%d+)%.$",
    function(a) spawnText("HEAL_CRIT","+"..a.."!",true) end)

-- HoT
addPat("CHAT_MSG_SPELL_PERIODIC_SELF_BUFFS","^You gain (%d+) health from your (.+) %(critical%)%.$",
    function(a) spawnText("HEAL_CRIT","+"..a.."!",true) end)
addPat("CHAT_MSG_SPELL_PERIODIC_SELF_BUFFS","^You gain (%d+) health from",
    function(a) spawnText("HOT","+"..a,false) end)

-- Resources
addPat("CHAT_MSG_SPELL_PERIODIC_SELF_BUFFS","^You gain (%d+) mana from",
    function(a) spawnText("MANA","+"..a.." mana",false) end)
addPat("CHAT_MSG_SPELL_PERIODIC_SELF_BUFFS","^You gain (%d+) energy from",
    function(a) spawnText("ENERGY","+"..a.." energy",false) end)
addPat("CHAT_MSG_SPELL_PERIODIC_SELF_BUFFS","^You gain (%d+) rage from",
    function(a) spawnText("RAGE","+"..a.." rage",false) end)

-- Buffs
addPat("CHAT_MSG_SPELL_SELF_BUFF","^You gain (.+)%.$",
    function(a) spawnText("BUFF","+"..a,false) end)
addPat("CHAT_MSG_SPELL_AURA_GONE_SELF","^(.+) fades from you%.$",
    function(a) spawnText("BUFF_GONE",a.." faded",false) end)

-- XP / Honor
addPat("CHAT_MSG_COMBAT_XP_GAIN","you gain (%d+) experience",
    function(a) spawnText("XP","+"..a.." XP",false) end)
addPat("CHAT_MSG_COMBAT_HONOR_GAIN","awarded (%d+) honor",
    function(a) spawnText("HONOR","+"..a.." Honor",false) end)

-- Dispatcher
local function dispatch(evtName, message)
    local list = patterns[evtName]
    if not list then return end
    for _, p in ipairs(list) do
        if string.find(p.pat, "%(") then
            local _, _, a, b = string.find(message, p.pat)
            if a then p.fn(a,b); return end
        else
            if string.find(message, p.pat) then p.fn(); return end
        end
    end
end

-------------------------------------------------------------------------------
-- EVENT REGISTRATION
-------------------------------------------------------------------------------
MT.eventFrame = CreateFrame("Frame", "FloaterFrame", UIParent)

local EVENTS = {
    "PLAYER_LOGIN",
    "CHAT_MSG_COMBAT_SELF_HITS",
    "CHAT_MSG_COMBAT_SELF_MISSES",
    "CHAT_MSG_SPELL_SELF_DAMAGE",
    "CHAT_MSG_SPELL_PERIODIC_CREATURE_DAMAGE",
    "CHAT_MSG_SPELL_PERIODIC_HOSTILEPLAYER_DAMAGE",
    "CHAT_MSG_COMBAT_CREATURE_VS_SELF_HITS",
    "CHAT_MSG_COMBAT_CREATURE_VS_SELF_MISSES",
    "CHAT_MSG_COMBAT_HOSTILEPLAYER_HITS",
    "CHAT_MSG_SPELL_CREATURE_VS_SELF_DAMAGE",
    "CHAT_MSG_SPELL_HOSTILEPLAYER_DAMAGE",
    "CHAT_MSG_SPELL_PERIODIC_SELF_DAMAGE",
    "CHAT_MSG_SPELL_SELF_BUFF",
    "CHAT_MSG_SPELL_FRIENDLYPLAYER_BUFF",
    "CHAT_MSG_SPELL_PERIODIC_SELF_BUFFS",
    "CHAT_MSG_SPELL_AURA_GONE_SELF",
    "CHAT_MSG_COMBAT_XP_GAIN",
    "CHAT_MSG_COMBAT_HONOR_GAIN",
}
for _, e in ipairs(EVENTS) do MT.eventFrame:RegisterEvent(e) end

MT.eventFrame:SetScript("OnEvent", function()
    if event == "PLAYER_LOGIN" then
        if not FloaterDB then FloaterDB = {} end
        -- global defaults
        for k, v in pairs(FloaterDefaults) do
            if FloaterDB[k] == nil then FloaterDB[k] = v end
        end
        -- type defaults
        if not FloaterDB.types then FloaterDB.types = {} end
        local typeDefs = buildTypeDefaults()
        for key, def in pairs(typeDefs) do
            if not FloaterDB.types[key] then
                FloaterDB.types[key] = def
            else
                for f2, v2 in pairs(def) do
                    if FloaterDB.types[key][f2] == nil then
                        FloaterDB.types[key][f2] = v2
                    end
                end
            end
        end
        -- group defaults
        if not FloaterDB.groups or table.getn(FloaterDB.groups) == 0 then
            FloaterDB.groups = defaultGroups()
        else
            -- backfill any missing groups
            local dg = defaultGroups()
            for gi = table.getn(FloaterDB.groups)+1, MAX_GROUPS do
                FloaterDB.groups[gi] = dg[gi]
            end
        end

        db = FloaterDB
        -- boom defaults
        if not FloaterDB.boom then
            FloaterDB.boom = FloaterDefaults.boom
        else
            for k, v in pairs(FloaterDefaults.boom) do
                if FloaterDB.boom[k] == nil then FloaterDB.boom[k] = v end
            end
        end
        suppressDefaultFCT()
        buildAnchors()
        updateAnchorPositions()
        setGroupsLocked(true)
        rebuildTypeToGroup()
        MT.eventFrame:SetScript("OnUpdate", onUpdate)
        DEFAULT_CHAT_FRAME:AddMessage(
            "|cffaaddffFloater|r loaded.  |cffffff00/fl|r to open settings.")
    else
        dispatch(event, arg1 or "")
    end
end)

-------------------------------------------------------------------------------
-- SLASH COMMAND
-------------------------------------------------------------------------------
SLASH_FLOATER1 = "/fl"
SLASH_FLOATER2 = "/floater"

SlashCmdList["FLOATER"] = function(msg)
    local _, _, cmd = string.find(msg, "^(%S*)")
    cmd = string.lower(cmd or "")
    if cmd == "" or cmd == "config" or cmd == "settings" then
        if FloaterSettings_Toggle then FloaterSettings_Toggle() end
    elseif cmd == "unlock" then
        setGroupsLocked(false)
        DEFAULT_CHAT_FRAME:AddMessage("|cffaaddffFloater|r groups unlocked — drag to reposition.")
    elseif cmd == "lock" then
        setGroupsLocked(true)
        DEFAULT_CHAT_FRAME:AddMessage("|cffaaddffFloater|r groups locked.")
    elseif cmd == "enable" then
        db.enabled = true; suppressDefaultFCT()
        DEFAULT_CHAT_FRAME:AddMessage("|cffaaddffFloater|r enabled.")
    elseif cmd == "disable" then
        db.enabled = false; restoreDefaultFCT()
        DEFAULT_CHAT_FRAME:AddMessage("|cffaaddffFloater|r disabled.")
    elseif cmd == "reset" then
        for k, v in pairs(FloaterDefaults) do FloaterDB[k] = v end
        FloaterDB.types  = buildTypeDefaults()
        FloaterDB.groups = defaultGroups()
        db = FloaterDB
        updateAnchorPositions()
        rebuildTypeToGroup()
        DEFAULT_CHAT_FRAME:AddMessage("|cffaaddffFloater|r reset to defaults.")
    else
        DEFAULT_CHAT_FRAME:AddMessage("|cffaaddffFloater|r — /fl  /fl unlock  /fl lock  /fl enable  /fl disable  /fl reset")
    end
end

-------------------------------------------------------------------------------
-- PUBLIC API
-------------------------------------------------------------------------------
function Floater_GetDB()             return db                  end
function Floater_Suppress()          suppressDefaultFCT()       end
function Floater_Restore()           restoreDefaultFCT()        end
function Floater_RebuildTypeToGroup() rebuildTypeToGroup()      end
function Floater_UpdateGroupPos(gi)
    local f = MT.anchors[gi]
    local g = db and db.groups and db.groups[gi]
    if f and g then
        f:ClearAllPoints()
        f:SetPoint("CENTER", UIParent, "CENTER", g.x or 0, g.y or -100)
        f._lbl:SetText(g.name or ("Group "..gi))
    end
end
function Floater_SetGroupsLocked(v)  setGroupsLocked(v)         end

function Floater_TestSpawn()
    for _, td in ipairs(FloaterTypes) do
        local isCrit = (td.key=="OUT_CRIT" or td.key=="IN_CRIT" or td.key=="HEAL_CRIT")
        spawnText(td.key, td.sample, isCrit)
    end
end

function Floater_TestSpawnKey(key, sample, isCrit)
    spawnText(key, sample, isCrit or (key=="OUT_CRIT" or key=="IN_CRIT" or key=="HEAL_CRIT"))
end

function Floater_TestGroup(gi)
    if not db or not db.groups or not db.groups[gi] then return end
    local g = db.groups[gi]
    for typeKey, _ in pairs(g.types) do
        for _, td in ipairs(FloaterTypes) do
            if td.key == typeKey then
                local isCrit = (typeKey=="OUT_CRIT" or typeKey=="IN_CRIT" or typeKey=="HEAL_CRIT")
                spawnText(typeKey, td.sample, isCrit)
                break
            end
        end
    end
end

function Floater_TestBoom()
    boomOnCrit((db and db.boom and db.boom.threshold or 1000) + 1)
end

function Floater_TestBoomStreak()
    local needed = (db and db.boom and db.boom.streakCount or 3)
    -- Force streak count to exactly the threshold so boomOnCrit fires the streak yell
    BOOM.streakCount  = needed - 1
    BOOM.lastCritTime = GetTime()
    boomOnCrit(0)
end
